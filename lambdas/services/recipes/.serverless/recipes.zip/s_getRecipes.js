
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'dabyun',
  applicationName: 'mca',
  appUid: 'P7V03j4zDPgXxShZgL',
  orgUid: '4420f94a-6283-4621-b6b0-1a6fc53e338d',
  deploymentUid: 'fe60e3fb-6586-4968-8ebe-1bd0371f1b7f',
  serviceName: 'recipes',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'recipes-dev-getRecipes', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.getRecipes, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}